close all;
plot(Xd2,Yd2,'b','LineWidth', 2);
hold on;
plot(x,y,'r--','LineWidth', 2);
hold on;
plot(Xd2_2,Yd2_21,'b','LineWidth', 2);
hold on;
plot(x1,y1,'r--','LineWidth', 2);
hold on;
plot(Xd2_3,Yd2_3,'b','LineWidth', 2);
hold on;
plot(x2,y2,'r--','LineWidth', 2);
hold on;
AUV_COL1= [1 0 0];
AUV_COL2= [0 1 0];
AUV_COL3= [0 0 1];
Scale = 0.002;
%Scale = 0.008;
% for i = 1:1:406
% alpha(i) = atan(5*cos(i/10));%������
% alpha(i) = atan(diff(y)/diff(x));%������
% alpha1(i) = atan(5*cos(i/10 - 1));
% alpha2(i) = atan(5*cos(i/10 - 2));
% 
% end
alpha = atan(diff(y)./diff(x));
alpha1 = atan(diff(y1)./diff(x1));
alpha2 = atan(diff(y2)./diff(x2));
for i = 1:20:407
 draw_kayaka(x(i),y(i),Scale, alpha(i),AUV_COL1 );
 hold on;
 draw_kayaka(x2(i),y2(i),Scale, alpha2(i),AUV_COL2 );
 hold on;
 draw_kayaka(x1(i),y1(i),Scale, alpha1(i),AUV_COL3 );
 hold on;
 
end