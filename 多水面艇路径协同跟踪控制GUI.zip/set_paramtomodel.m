function set_paramtomodel(model_name,GUI_c1)

set_param(strcat(model_name,'/GUI_c1'), 'Value',num2str(GUI_c1));
% set_param(strcat(model_name,'/GUI_c2'), 'Value',num2str(GUI_c1));
% set_param(strcat(model_name,'/GUI_c3'), 'Value',num2str(GUI_c1));

end