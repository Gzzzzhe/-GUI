function [ x_shape_plot, y_shape_plot, H, G] = draw_kayaka(x_center, y_center,Scale, heading,c )
load LUNKUO.mat
% x_shape = [0,0.3,0.7,1,0.75,0.5,0.25,0,-0.25,-0.5,-0.75,-1,-0.7,-0.3,0];
% y_shape = [6,4.6,2,0,-1,-1.5,-1.8,-2,-1.8,-1.5,-1,0,2,4.6,6];
% x_shape = C(1,:);
% y_shape = C(2,:);
%������
B = C(:,1:2993);
x_shape = B(1,:);
y_shape = B(2,:);
D = C(:,9082:1.07e+04);D(1,1620) = 369;D(2,1620) = 75.46;
%�ڰ�Բ
x_shape2 = D(1,:);
y_shape2 = D(2,:);
[m_shape, n_shape] = size(x_shape);
[m_shape2, n_shape2] = size(x_shape2);
for i=1:n_shape
    length = sqrt(x_shape(i)^2+y_shape(i)^2);
    origional_theta = atan2(y_shape(i),x_shape(i))-pi/2;

    x_shape_new(i) = length*Scale*cos(heading-pi/2+origional_theta);
    y_shape_new(i) = length*Scale*sin(heading-pi/2+origional_theta);
end

for i=1:n_shape2
    length2 = sqrt(x_shape2(i)^2+y_shape2(i)^2);
    origional_theta2 = atan2(y_shape2(i),x_shape2(i))-pi/2;
    x_shape_new2(i) = length2*Scale*cos(heading-pi/2+origional_theta2);
    y_shape_new2(i) = length2*Scale*sin(heading-pi/2+origional_theta2);
end

x_shape_plot = (x_shape_new+x_center + 0.75);
y_shape_plot = (y_shape_new+y_center + 0.75);
x_shape_plot2 = (x_shape_new2+x_center + 0.75);
y_shape_plot2 = (y_shape_new2+y_center + 0.75);

% x_shape_plot = (x_shape_new+x_center + 3);
% y_shape_plot = (y_shape_new+y_center + 3.35);
% x_shape_plot2 = (x_shape_new2+x_center + 3);
% y_shape_plot2 = (y_shape_new2+y_center + 3.35);


H=plot(x_shape_plot, y_shape_plot,'Linewidth',1.3,'Color',[0 0 0]);
hold on 
plot(x_shape_plot2, y_shape_plot2,'Linewidth',1.3,'Color',[0 0 0]);


G=patch(x_shape_plot, y_shape_plot,c);
patch(x_shape_plot2, y_shape_plot2,c);



end