plot(Xd3,Yd3,'b','LineWidth', 2);
hold on;
plot(x,y,'r--','LineWidth', 2);
hold on;
plot(Xd3_2,Yd3_2,'b','LineWidth', 2);
hold on;
plot(x1,y1,'r--','LineWidth', 2);
hold on;
plot(Xd3_3,Yd3_3,'b','LineWidth', 2);
hold on;
plot(x2,y2,'r--','LineWidth', 2);
hold on;
AUV_COL1= [1 0 0];
AUV_COL2= [0 1 0];
AUV_COL3= [0 0 1];
Scale = 0.0005;
%Scale = 0.008;
% for i = 1:1:406
% alpha(i) = atan(5*cos(i/10));%������
% alpha(i) = atan(diff(y)/diff(x));%������
% alpha1(i) = atan(5*cos(i/10 - 1));
% alpha2(i) = atan(5*cos(i/10 - 2));
% 
% end
alpha = atan2(diff(y),diff(x));
alpha1 = atan2(diff(y1),diff(x1));
alpha2 = atan2(diff(y2),diff(x2));
for i = 1:20:length(x)
 draw_kayaka(x(i),y(i),Scale, alpha(i),AUV_COL1 );
 hold on;
 draw_kayaka(x2(i),y2(i),Scale, alpha2(i),AUV_COL2 );
 hold on;
 draw_kayaka(x1(i),y1(i),Scale, alpha1(i),AUV_COL3 );
 hold on;
end